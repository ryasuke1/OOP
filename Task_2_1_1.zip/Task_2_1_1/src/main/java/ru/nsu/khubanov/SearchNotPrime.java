package ru.nsu.khubanov;

public abstract class SearchNotPrime {

    public abstract boolean HasNotPrime(int[] nums);
}
